import type { FormField, FormInputValues } from "./formSchema"

/**
 * Evaluates the conditional logic for a given field.
 * @param field The field schema, potentially containing conditional properties.
 * @param allFormValues The current values of all fields in the form.
 * @returns True if the field should be visible, false otherwise.
 */
export function evaluateCondition(field: FormField, allFormValues: FormInputValues): boolean {
  if (!field.isConditional || !field.conditionFieldId || !field.conditionOperator) {
    return true // If not conditional, always visible
  }

  const targetFieldValue = allFormValues[field.conditionFieldId]
  const conditionValue = field.conditionValue

  // Handle cases where the target field value is undefined (e.g., not yet entered, or hidden itself)
  if (targetFieldValue === undefined || targetFieldValue === null || targetFieldValue === "") {
    // If the condition is 'is not equal to' and target is empty, it might be considered true
    // For other operators, an empty target value usually means the condition is not met
    return (
      field.conditionOperator === "!===" &&
      (conditionValue === undefined || conditionValue === null || conditionValue === "")
    )
  }

  switch (field.conditionOperator) {
    case "===":
      return targetFieldValue === conditionValue
    case "!==":
      return targetFieldValue !== conditionValue
    case ">":
      return (
        typeof targetFieldValue === "number" && typeof conditionValue === "number" && targetFieldValue > conditionValue
      )
    case "<":
      return (
        typeof targetFieldValue === "number" && typeof conditionValue === "number" && targetFieldValue < conditionValue
      )
    case ">=":
      return (
        typeof targetFieldValue === "number" && typeof conditionValue === "number" && targetFieldValue >= conditionValue
      )
    case "<=":
      return (
        typeof targetFieldValue === "number" && typeof conditionValue === "number" && targetFieldValue <= conditionValue
      )
    case "includes":
      if (typeof targetFieldValue === "string" && typeof conditionValue === "string") {
        return targetFieldValue.includes(conditionValue)
      }
      if (
        Array.isArray(targetFieldValue) &&
        (typeof conditionValue === "string" || typeof conditionValue === "number")
      ) {
        return targetFieldValue.includes(conditionValue)
      }
      return false
    case "!includes":
      if (typeof targetFieldValue === "string" && typeof conditionValue === "string") {
        return !targetFieldValue.includes(conditionValue)
      }
      if (
        Array.isArray(targetFieldValue) &&
        (typeof conditionValue === "string" || typeof conditionValue === "number")
      ) {
        return !targetFieldValue.includes(conditionValue)
      }
      return false
    default:
      return true // Unknown operator, default to visible
  }
}
