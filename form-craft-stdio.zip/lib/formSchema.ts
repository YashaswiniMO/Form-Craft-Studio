export type FieldType = "text" | "number" | "textarea" | "select" | "radio" | "checkbox" | "date"

export type ValidationRuleType =
  | "notEmpty"
  | "minLength"
  | "maxLength"
  | "email"
  | "password"
  | "url"
  | "regex"
  | "minNumber"
  | "maxNumber" // Added new validation types

export type ValidationRule = {
  type: ValidationRuleType
  value?: string | number // For minLength, maxLength, password regex, regex pattern, minNumber, maxNumber
  message: string
}

export type ConditionOperator = "===" | "!==" | ">" | "<" | ">=" | "<=" | "includes" | "!includes" // New type for conditional operators

export type FormField = {
  id: string
  label: string
  type: FieldType
  required: boolean
  defaultValue: string | number | boolean | string[] // For checkbox, select, radio
  validations: ValidationRule[]
  isDerived: boolean
  parentFieldIds?: string[]
  computationLogic?: string // JS expression or function body
  options?: { label: string; value: string }[] // For select, radio, checkbox
  isConditional?: boolean // New: Is this field conditionally rendered?
  conditionFieldId?: string // New: ID of the field this field depends on
  conditionOperator?: ConditionOperator // New: Operator for the condition
  conditionValue?: string | number | boolean | string[] // New: Value to compare against
}

export type FormSchema = {
  id: string
  name: string
  createdAt: string
  fields: FormField[]
}

export type FormInputValues = {
  [fieldId: string]: any
}
