import type { FormInputValues } from "./formSchema"

/**
 * Evaluates a JavaScript expression for a derived field.
 * @param logic The JavaScript expression string (e.g., "field_id_1 + field_id_2").
 * @param parentValues An object where keys are parent field IDs and values are their current inputs.
 * @returns The computed value.
 */
export function evaluateDerivedField(logic: string, parentValues: FormInputValues): any {
  // Create a function from the logic string, passing parent values as arguments
  // This is a simplified approach for the assignment.
  // In a production environment, using `eval` or `new Function` with user input is a security risk.
  // A safer approach would be to parse the logic into an AST and evaluate it in a sandboxed environment,
  // or provide a limited set of predefined functions/operators.

  const argNames = Object.keys(parentValues)
  const argValues = Object.values(parentValues)

  try {
    // Dynamically create a function that takes parent field IDs as arguments
    // and returns the result of the logic.
    const func = new Function(...argNames, `return ${logic};`)
    return func(...argValues)
  } catch (error) {
    console.error("Error evaluating derived field logic:", error)
    return "Error" // Indicate an error in computation
  }
}
