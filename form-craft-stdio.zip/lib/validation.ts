import type { FormField } from "./formSchema"

/**
 * Validates a single form field based on its configured rules.
 * @param field The field schema.
 * @param value The current value of the field.
 * @returns An error message string if validation fails, otherwise null.
 */
export function validateField(field: FormField, value: any): string | null {
  // Handle required validation first
  if (
    field.required &&
    (value === null || value === undefined || value === "" || (Array.isArray(value) && value.length === 0))
  ) {
    return `${field.label} is required.`
  }

  // If not required and value is empty, no further validation needed
  if (
    !field.required &&
    (value === null || value === undefined || value === "" || (Array.isArray(value) && value.length === 0))
  ) {
    return null
  }

  for (const rule of field.validations) {
    switch (rule.type) {
      case "notEmpty":
        // This is already handled by the `required` check above, but kept for explicit rule.
        if (value === null || value === undefined || value === "" || (Array.isArray(value) && value.length === 0)) {
          return rule.message || `${field.label} cannot be empty.`
        }
        break
      case "minLength":
        if (typeof value === "string" && value.length < (rule.value as number)) {
          return rule.message || `${field.label} must be at least ${rule.value} characters.`
        }
        break
      case "maxLength":
        if (typeof value === "string" && value.length > (rule.value as number)) {
          return rule.message || `${field.label} cannot exceed ${rule.value} characters.`
        }
        break
      case "email":
        // Basic email regex
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
        if (typeof value === "string" && !emailRegex.test(value)) {
          return rule.message || "Please enter a valid email address."
        }
        break
      case "url":
        // Basic URL regex
        const urlRegex =
          /^(https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|www\.[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|https?:\/\/[a-zA-Z0-9]+\.[^\s]{2,}|[a-zA-Z0-9]+\.[^\s]{2,})$/i
        if (typeof value === "string" && !urlRegex.test(value)) {
          return rule.message || "Please enter a valid URL."
        }
        break
      case "password":
        // Custom password rule: requires a regex string in rule.value
        if (typeof value === "string" && rule.value) {
          try {
            const passwordRegex = new RegExp(rule.value as string)
            if (!passwordRegex.test(value)) {
              return rule.message || "Password does not meet the requirements."
            }
          } catch (e) {
            console.error("Invalid password regex:", rule.value, e)
            return "Invalid password validation rule configured."
          }
        }
        break
      case "regex":
        if (typeof value === "string" && rule.value) {
          try {
            const customRegex = new RegExp(rule.value as string)
            if (!customRegex.test(value)) {
              return rule.message || "Input does not match the required pattern."
            }
          } catch (e) {
            console.error("Invalid custom regex:", rule.value, e)
            return "Invalid custom regex rule configured."
          }
        }
        break
      case "minNumber":
        if (typeof value === "number" && value < (rule.value as number)) {
          return rule.message || `${field.label} must be at least ${rule.value}.`
        }
        break
      case "maxNumber":
        if (typeof value === "number" && value > (rule.value as number)) {
          return rule.message || `${field.label} cannot exceed ${rule.value}.`
        }
        break
      default:
        break
    }
  }

  return null // No errors
}
