import type { FormSchema } from "./formSchema"

const FORMS_STORAGE_KEY = "dynamicForms"

export const loadFormsFromLocalStorage = (): FormSchema[] => {
  if (typeof window === "undefined") {
    return []
  }
  try {
    const serializedForms = localStorage.getItem(FORMS_STORAGE_KEY)
    if (serializedForms === null) {
      return []
    }
    return JSON.parse(serializedForms) as FormSchema[]
  } catch (error) {
    console.error("Error loading forms from localStorage:", error)
    return []
  }
}

export const saveFormsToLocalStorage = (forms: FormSchema[]): void => {
  if (typeof window === "undefined") {
    return
  }
  try {
    const serializedForms = JSON.stringify(forms)
    localStorage.setItem(FORMS_STORAGE_KEY, serializedForms)
  } catch (error) {
    console.error("Error saving forms to localStorage:", error)
  }
}
