"use client"

import type React from "react"
import { ThemeProvider, createTheme } from "@mui/material/styles"
import CssBaseline from "@mui/material/CssBaseline"
import { blue, indigo, green, red, grey, deepOrange } from "@mui/material/colors" // Import more colors
import { useState, useMemo, createContext, useContext } from "react"

// Define the context type
interface ColorModeContextType {
  mode: "light" | "dark"
  toggleColorMode: () => void
}

// Create the context
const ColorModeContext = createContext<ColorModeContextType>({
  mode: "light",
  toggleColorMode: () => {},
})

// Custom hook to use the color mode context
export const useColorMode = () => useContext(ColorModeContext)

export function MuiThemeProvider({ children }: { children: React.ReactNode }) {
  const [mode, setMode] = useState<"light" | "dark">("light") // Default to light mode

  const colorMode = useMemo(
    () => ({
      toggleColorMode: () => {
        setMode((prevMode) => (prevMode === "light" ? "dark" : "light"))
      },
      mode,
    }),
    [mode],
  )

  const theme = useMemo(
    () =>
      createTheme({
        palette: {
          mode, // Set palette mode dynamically
          primary: {
            main: mode === "light" ? blue[700] : blue[400], // Deep blue for light, slightly lighter for dark
          },
          secondary: {
            main: mode === "light" ? indigo[500] : indigo[300], // Indigo for secondary
          },
          error: {
            main: red[500],
          },
          success: {
            main: green[600], // Slightly darker green for success
          },
          info: {
            main: mode === "light" ? blue[400] : blue[200], // Lighter blue for info
          },
          warning: {
            main: deepOrange[500], // Orange for warnings
          },
          background: {
            default: mode === "light" ? grey[100] : "#1a202c", // Light grey/blue for light, deep dark blue for dark
            paper: mode === "light" ? "#ffffff" : "#2d3748", // Pure white for light paper, slightly lighter dark for dark paper
          },
          text: {
            primary: mode === "light" ? "rgba(0, 0, 0, 0.87)" : "#ffffff",
            secondary: mode === "light" ? "rgba(0, 0, 0, 0.6)" : "rgba(255, 255, 255, 0.7)",
          },
        },
        typography: {
          fontFamily: "Poppins, sans-serif",
          h4: {
            fontWeight: 600,
          },
          h5: {
            fontWeight: 500,
          },
          h6: {
            fontWeight: 500,
          },
        },
        components: {
          MuiButton: {
            styleOverrides: {
              root: {
                textTransform: "none",
                borderRadius: 8,
              },
            },
          },
          MuiPaper: {
            styleOverrides: {
              root: {
                borderRadius: 12,
              },
            },
          },
          MuiTextField: {
            defaultProps: {
              variant: "outlined",
            },
          },
        },
      }),
    [mode], // Re-create theme when mode changes
  )

  return (
    <ColorModeContext.Provider value={colorMode}>
      <ThemeProvider theme={theme}>
        <CssBaseline />
        {children}
      </ThemeProvider>
    </ColorModeContext.Provider>
  )
}
