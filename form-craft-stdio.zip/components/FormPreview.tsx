"use client"

import type React from "react"
import { useState, useEffect, useCallback } from "react"
import type { FormSchema, FormInputValues } from "@/lib/formSchema"
import FormFieldRenderer from "./FormFieldRenderer"
import { validateField } from "@/lib/validation"
import { evaluateDerivedField } from "@/lib/derivedFieldLogic"
import { evaluateCondition } from "@/lib/conditionalLogic" // Import evaluateCondition
import { Button, Paper, Alert, Box, Typography, Dialog, DialogTitle, DialogContent, DialogActions } from "@mui/material" // Import Dialog components

interface FormPreviewProps {
  formSchema: FormSchema
}

export default function FormPreview({ formSchema }: FormPreviewProps) {
  const [formValues, setFormValues] = useState<FormInputValues>({})
  const [formErrors, setFormErrors] = useState<FormInputValues>({})
  const [formSubmitted, setFormSubmitted] = useState(false)
  const [submitSuccess, setSubmitSuccess] = useState(false)
  const [submittedData, setSubmittedData] = useState<FormInputValues | null>(null)
  const [confirmDialogOpen, setConfirmDialogOpen] = useState(false) // State for confirmation dialog

  // Initialize form values with default values from schema
  useEffect(() => {
    const initialValues: FormInputValues = {}
    formSchema.fields.forEach((field) => {
      if (field.isDerived) {
        initialValues[field.id] = undefined
      } else if (field.type === "checkbox") {
        initialValues[field.id] = field.defaultValue || []
      } else {
        initialValues[field.id] = field.defaultValue || ""
      }
    })
    setFormValues(initialValues)
    setFormErrors({})
    setFormSubmitted(false)
    setSubmitSuccess(false)
    setSubmittedData(null)
  }, [formSchema])

  // Effect to re-evaluate derived fields and handle conditional visibility
  useEffect(() => {
    const newDerivedValues: FormInputValues = {}
    let changed = false

    const visibleFields = formSchema.fields.filter((field) => evaluateCondition(field, formValues))

    formSchema.fields.forEach((field) => {
      const isFieldVisible = visibleFields.some((f) => f.id === field.id)

      if (!isFieldVisible) {
        // If field becomes hidden, clear its value and errors
        if (formValues[field.id] !== undefined) {
          newDerivedValues[field.id] = undefined
          changed = true
        }
        if (formErrors[field.id] !== undefined) {
          setFormErrors((prevErrors) => {
            const newErrors = { ...prevErrors }
            delete newErrors[field.id]
            return newErrors
          })
        }
      } else if (field.isDerived && field.parentFieldIds && field.computationLogic) {
        const parentValues: FormInputValues = {}
        field.parentFieldIds.forEach((parentId) => {
          parentValues[parentId] = formValues[parentId]
        })

        try {
          const computedValue = evaluateDerivedField(field.computationLogic, parentValues)
          if (computedValue !== formValues[field.id]) {
            newDerivedValues[field.id] = computedValue
            changed = true
          }
        } catch (e) {
          console.error(`Error evaluating derived field ${field.label}:`, e)
          if (formValues[field.id] !== "Error") {
            newDerivedValues[field.id] = "Error"
            changed = true
          }
        }
      }
    })

    if (changed) {
      setFormValues((prevValues) => ({ ...prevValues, ...newDerivedValues }))
    }
  }, [formValues, formSchema.fields, formErrors]) // Depend on formValues and formSchema.fields

  const handleFieldChange = useCallback((fieldId: string, value: any) => {
    setFormValues((prevValues) => ({
      ...prevValues,
      [fieldId]: value,
    }))

    setFormErrors((prevErrors) => {
      const newErrors = { ...prevErrors }
      delete newErrors[fieldId]
      return newErrors
    })
  }, [])

  const validateForm = useCallback(() => {
    let isValid = true
    const newErrors: FormInputValues = {}

    // Only validate visible fields
    const visibleFields = formSchema.fields.filter((field) => evaluateCondition(field, formValues))

    visibleFields.forEach((field) => {
      if (!field.isDerived) {
        const errorMessage = validateField(field, formValues[field.id])
        if (errorMessage) {
          newErrors[field.id] = errorMessage
          isValid = false
        }
      }
    })
    setFormErrors(newErrors)
    return isValid
  }, [formSchema.fields, formValues])

  const handlePreSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setFormSubmitted(true) // Mark as submitted to show initial errors
    const isValid = validateForm()

    if (isValid) {
      setConfirmDialogOpen(true) // Open confirmation dialog if valid
    } else {
      setSubmitSuccess(false)
      setSubmittedData(null)
    }
  }

  const handleConfirmSubmit = () => {
    setConfirmDialogOpen(false) // Close dialog
    // Form is already validated by handlePreSubmit
    setSubmitSuccess(true)
    // Filter out undefined values from hidden fields before storing submitted data
    const finalSubmittedData = Object.entries(formValues).reduce((acc, [fieldId, value]) => {
      const field = formSchema.fields.find((f) => f.id === fieldId)
      if (field && evaluateCondition(field, formValues)) {
        acc[fieldId] = value
      }
      return acc
    }, {} as FormInputValues)

    setSubmittedData(finalSubmittedData)
    console.log("Form Submitted Successfully!", finalSubmittedData)
  }

  const handleResetForm = () => {
    const initialValues: FormInputValues = {}
    formSchema.fields.forEach((field) => {
      if (field.type === "checkbox") {
        initialValues[field.id] = field.defaultValue || []
      } else {
        initialValues[field.id] = field.defaultValue || ""
      }
    })
    setFormValues(initialValues)
    setFormErrors({})
    setFormSubmitted(false)
    setSubmitSuccess(false)
    setSubmittedData(null)
  }

  return (
    <Paper elevation={3} sx={{ p: 4, mt: 3 }}>
      <Typography variant="h5" gutterBottom sx={{ fontWeight: 600, color: "#3f51b5" }}>
        {formSchema.name}
      </Typography>
      <form onSubmit={handlePreSubmit}>
        {formSchema.fields.map((field) => {
          const isVisible = evaluateCondition(field, formValues)
          return (
            <FormFieldRenderer
              key={field.id}
              field={field}
              value={formValues[field.id]}
              onChange={(val) => handleFieldChange(field.id, val)}
              error={formSubmitted && !!formErrors[field.id]}
              helperText={formSubmitted ? formErrors[field.id] || "" : ""}
              disabled={field.isDerived || !isVisible} // Disable if derived or hidden
              hidden={!isVisible} // Hide if not visible
            />
          )
        })}
        <Box sx={{ display: "flex", gap: 2, mt: 3 }}>
          <Button type="submit" variant="contained" color="primary">
            Submit Form
          </Button>
          <Button type="button" variant="outlined" onClick={handleResetForm}>
            Reset Form
          </Button>
        </Box>

        {formSubmitted && !submitSuccess && Object.keys(formErrors).length > 0 && (
          <Alert severity="error" sx={{ mt: 2 }}>
            Please correct the errors in the form.
          </Alert>
        )}
        {formSubmitted && submitSuccess && (
          <Alert severity="success" sx={{ mt: 2 }}>
            Form submitted successfully!
          </Alert>
        )}

        {submittedData && submitSuccess && (
          <Box sx={{ mt: 4, p: 3, border: "1px dashed #a7d9ff", borderRadius: 2, backgroundColor: "#eaf6ff" }}>
            <Typography variant="h6" gutterBottom sx={{ fontWeight: 500, color: "#1a237e" }}>
              Submitted Data:
            </Typography>
            <pre style={{ whiteSpace: "pre-wrap", wordBreak: "break-all", fontSize: "0.9em", color: "#333" }}>
              {JSON.stringify(
                Object.entries(submittedData).reduce(
                  (acc, [fieldId, value]) => {
                    const field = formSchema.fields.find((f) => f.id === fieldId)
                    if (field) {
                      acc[field.label] = value
                    }
                    return acc
                  },
                  {} as Record<string, any>,
                ),
                null,
                2,
              )}
            </pre>
          </Box>
        )}
      </form>

      {/* Confirmation Dialog */}
      <Dialog open={confirmDialogOpen} onClose={() => setConfirmDialogOpen(false)}>
        <DialogTitle>Confirm Submission</DialogTitle>
        <DialogContent>
          <Typography>Are you sure you want to submit this form?</Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setConfirmDialogOpen(false)}>Cancel</Button>
          <Button onClick={handleConfirmSubmit} variant="contained" color="primary">
            Confirm
          </Button>
        </DialogActions>
      </Dialog>
    </Paper>
  )
}
