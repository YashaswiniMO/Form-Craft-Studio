"use client"

import type React from "react"
import type { FormField, ValidationRule, ConditionOperator } from "@/lib/formSchema" // Import ConditionOperator
import {
  TextField,
  FormControlLabel,
  Switch,
  Box,
  Typography,
  Button,
  IconButton,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  FormHelperText,
} from "@mui/material"
import AddIcon from "@mui/icons-material/Add"
import DeleteIcon from "@mui/icons-material/Delete"
import ValidationRulesEditor from "./ValidationRulesEditor"
import DerivedFieldEditor from "./DerivedFieldEditor"

interface FieldConfiguratorProps {
  field: FormField
  allFields: FormField[] // All fields in the current form, needed for derived fields and conditional logic
  onUpdate: (updatedField: FormField) => void
}

export default function FieldConfigurator({ field, allFields, onUpdate }: FieldConfiguratorProps) {
  const handleLabelChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onUpdate({ ...field, label: e.target.value })
  }

  const handleRequiredChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onUpdate({ ...field, required: e.target.checked })
  }

  const handleDefaultValueChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    let value: string | number | boolean | string[] = e.target.value
    if (field.type === "number") {
      value = Number.parseFloat(value) || 0
    }
    onUpdate({ ...field, defaultValue: value })
  }

  const handleValidationUpdate = (validations: ValidationRule[]) => {
    onUpdate({ ...field, validations })
  }

  const handleDerivedToggle = (e: React.ChangeEvent<HTMLInputElement>) => {
    onUpdate({ ...field, isDerived: e.target.checked, parentFieldIds: [], computationLogic: "" })
  }

  const handleDerivedUpdate = (parentFieldIds: string[], computationLogic: string) => {
    onUpdate({ ...field, parentFieldIds, computationLogic })
  }

  const handleConditionalToggle = (e: React.ChangeEvent<HTMLInputElement>) => {
    onUpdate({
      ...field,
      isConditional: e.target.checked,
      conditionFieldId: undefined,
      conditionOperator: undefined,
      conditionValue: undefined,
    })
  }

  const handleConditionChange = (prop: "conditionFieldId" | "conditionOperator" | "conditionValue", value: any) => {
    onUpdate({ ...field, [prop]: value })
  }

  const handleOptionChange = (index: number, type: "label" | "value", value: string) => {
    const newOptions = [...(field.options || [])]
    newOptions[index] = { ...newOptions[index], [type]: value }
    onUpdate({ ...field, options: newOptions })
  }

  const handleAddOption = () => {
    const newOptions = [...(field.options || [])]
    newOptions.push({ label: `Option ${newOptions.length + 1}`, value: `option${newOptions.length + 1}` })
    onUpdate({ ...field, options: newOptions })
  }

  const handleRemoveOption = (index: number) => {
    const newOptions = [...(field.options || [])]
    newOptions.splice(index, 1)
    onUpdate({ ...field, options: newOptions })
  }

  const availableConditionFields = allFields.filter((f) => f.id !== field.id)

  return (
    <Box sx={{ display: "flex", flexDirection: "column", gap: 2 }}>
      <TextField label="Field Label" value={field.label} onChange={handleLabelChange} fullWidth />

      <FormControlLabel
        control={<Switch checked={field.required} onChange={handleRequiredChange} />}
        label="Required"
      />

      {!field.isDerived && (
        <TextField
          label="Default Value"
          value={field.defaultValue}
          onChange={handleDefaultValueChange}
          type={field.type === "number" ? "number" : "text"}
          fullWidth
        />
      )}

      {(field.type === "select" || field.type === "radio" || field.type === "checkbox") && (
        <Box sx={{ mt: 2, border: "1px dashed #ccc", p: 2, borderRadius: 1 }}>
          <Typography variant="subtitle1" gutterBottom>
            Options
          </Typography>
          {field.options?.map((option, index) => (
            <Box key={index} sx={{ display: "flex", gap: 1, mb: 1, alignItems: "center" }}>
              <TextField
                label={`Option ${index + 1} Label`}
                value={option.label}
                onChange={(e) => handleOptionChange(index, "label", e.target.value)}
                size="small"
                sx={{ flex: 1 }}
              />
              <TextField
                label={`Option ${index + 1} Value`}
                value={option.value}
                onChange={(e) => handleOptionChange(index, "value", e.target.value)}
                size="small"
                sx={{ flex: 1 }}
              />
              <IconButton onClick={() => handleRemoveOption(index)} size="small" color="error">
                <DeleteIcon fontSize="small" />
              </IconButton>
            </Box>
          ))}
          <Button startIcon={<AddIcon />} onClick={handleAddOption} size="small" sx={{ mt: 1 }}>
            Add Option
          </Button>
        </Box>
      )}

      <ValidationRulesEditor field={field} validations={field.validations} onUpdate={handleValidationUpdate} />

      <FormControlLabel
        control={<Switch checked={field.isDerived} onChange={handleDerivedToggle} />}
        label="Derived Field"
      />

      {field.isDerived && (
        <DerivedFieldEditor
          field={field}
          allFields={allFields.filter((f) => f.id !== field.id)} // Exclude self from parent options
          onUpdate={handleDerivedUpdate}
        />
      )}

      <FormControlLabel
        control={<Switch checked={field.isConditional} onChange={handleConditionalToggle} />}
        label="Conditional Field"
      />

      {field.isConditional && (
        <Box sx={{ border: "1px solid #ddd", p: 2, borderRadius: 1, mt: 2 }}>
          <Typography variant="subtitle1" gutterBottom>
            Conditional Logic
          </Typography>
          <FormControl fullWidth margin="normal">
            <InputLabel id="condition-field-label">Show if field...</InputLabel>
            <Select
              labelId="condition-field-label"
              value={field.conditionFieldId || ""}
              onChange={(e) => handleConditionChange("conditionFieldId", e.target.value)}
              label="Show if field..."
            >
              {availableConditionFields.map((f) => (
                <MenuItem key={f.id} value={f.id}>
                  {f.label} ({f.type})
                </MenuItem>
              ))}
            </Select>
            <FormHelperText>Select a field that this field's visibility depends on.</FormHelperText>
          </FormControl>

          {field.conditionFieldId && (
            <>
              <FormControl fullWidth margin="normal">
                <InputLabel id="condition-operator-label">Operator</InputLabel>
                <Select
                  labelId="condition-operator-label"
                  value={field.conditionOperator || ""}
                  onChange={(e) => handleConditionChange("conditionOperator", e.target.value as ConditionOperator)}
                  label="Operator"
                >
                  <MenuItem value="===">is equal to</MenuItem>
                  <MenuItem value="!==">is not equal to</MenuItem>
                  <MenuItem value=">">is greater than (for numbers)</MenuItem>
                  <MenuItem value="<">is less than (for numbers)</MenuItem>
                  <MenuItem value=">=">is greater than or equal to (for numbers)</MenuItem>
                  <MenuItem value="<=">is less than or equal to (for numbers)</MenuItem>
                  <MenuItem value="includes">includes (for text/checkboxes)</MenuItem>
                  <MenuItem value="!includes">does not include (for text/checkboxes)</MenuItem>
                </Select>
              </FormControl>

              {field.conditionOperator && (
                <TextField
                  label="Value"
                  value={field.conditionValue || ""}
                  onChange={(e) => {
                    let val: string | number | boolean = e.target.value
                    const targetField = availableConditionFields.find((f) => f.id === field.conditionFieldId)
                    if (targetField?.type === "number") {
                      val = Number.parseFloat(e.target.value)
                    } else if (targetField?.type === "checkbox") {
                      // For checkbox, conditionValue might be a single string to check inclusion
                      // Or for boolean, if we add boolean type fields
                    }
                    handleConditionChange("conditionValue", val)
                  }}
                  fullWidth
                  margin="normal"
                  type={
                    availableConditionFields.find((f) => f.id === field.conditionFieldId)?.type === "number"
                      ? "number"
                      : "text"
                  }
                  placeholder="Enter value to compare against"
                />
              )}
            </>
          )}
        </Box>
      )}
    </Box>
  )
}
