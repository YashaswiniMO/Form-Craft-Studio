"use client"

import type React from "react"
import type { FormField } from "@/lib/formSchema"
import { Box, Typography, FormControl, InputLabel, Select, MenuItem, TextField, FormHelperText } from "@mui/material"

interface DerivedFieldEditorProps {
  field: FormField
  allFields: FormField[]
  onUpdate: (parentFieldIds: string[], computationLogic: string) => void
}

export default function DerivedFieldEditor({ field, allFields, onUpdate }: DerivedFieldEditorProps) {
  const handleParentChange = (event: any) => {
    const {
      target: { value },
    } = event
    onUpdate(typeof value === "string" ? value.split(",") : value, field.computationLogic || "")
  }

  const handleLogicChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    onUpdate(field.parentFieldIds || [], e.target.value)
  }

  return (
    <Box sx={{ border: "1px solid #ddd", p: 2, borderRadius: 1, mt: 2 }}>
      <Typography variant="subtitle1" gutterBottom>
        Derived Field Configuration
      </Typography>
      <FormControl fullWidth margin="normal">
        <InputLabel id="parent-fields-label">Parent Field(s)</InputLabel>
        <Select
          labelId="parent-fields-label"
          multiple
          value={field.parentFieldIds || []}
          onChange={handleParentChange}
          label="Parent Field(s)"
          renderValue={(selected) =>
            (selected as string[]).map((id) => allFields.find((f) => f.id === id)?.label || id).join(", ")
          }
        >
          {allFields.map((f) => (
            <MenuItem key={f.id} value={f.id}>
              {f.label} ({f.type})
            </MenuItem>
          ))}
        </Select>
        <FormHelperText>Select one or more fields whose values will be used for computation.</FormHelperText>
      </FormControl>

      <TextField
        label="Computation Logic (JavaScript)"
        multiline
        rows={4}
        value={field.computationLogic || ""}
        onChange={handleLogicChange}
        fullWidth
        margin="normal"
        placeholder="Example: parentField1 + parentField2"
      />
      <FormHelperText>
        Enter a JavaScript expression. Parent field values are available as variables named by their IDs (e.g.,
        `field_id_1`).
        <br />
        <Typography component="span" color="error" sx={{ fontWeight: "bold" }}>
          Warning: Using `eval()` or `new Function()` for user-provided code can be a security risk in production.
        </Typography>
      </FormHelperText>
    </Box>
  )
}
