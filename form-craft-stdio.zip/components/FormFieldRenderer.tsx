"use client"
import type { FormField } from "@/lib/formSchema"
import {
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  RadioGroup,
  FormControlLabel,
  Radio,
  Checkbox,
  FormGroup,
  FormHelperText,
  Box, // Import Box
} from "@mui/material"

interface FormFieldRendererProps {
  field: FormField
  value: any
  onChange: (value: any) => void
  error: boolean
  helperText: string
  disabled?: boolean
  hidden?: boolean // New prop for conditional visibility
}

export default function FormFieldRenderer({
  field,
  value,
  onChange,
  error,
  helperText,
  disabled,
  hidden, // Destructure hidden
}: FormFieldRendererProps) {
  if (hidden) {
    return null // Don't render if hidden
  }

  const commonProps = {
    fullWidth: true,
    margin: "normal" as const,
    error: error,
    helperText: helperText,
    disabled: disabled,
  }

  let fieldComponent
  switch (field.type) {
    case "text":
    case "number":
    case "date":
      fieldComponent = (
        <TextField
          label={field.label}
          type={field.type === "date" ? "date" : field.type === "number" ? "number" : "text"}
          value={value || ""}
          onChange={(e) => onChange(e.target.value)}
          {...commonProps}
          InputLabelProps={field.type === "date" ? { shrink: true } : {}}
        />
      )
      break
    case "textarea":
      fieldComponent = (
        <TextField
          label={field.label}
          multiline
          rows={4}
          value={value || ""}
          onChange={(e) => onChange(e.target.value)}
          {...commonProps}
        />
      )
      break
    case "select":
      fieldComponent = (
        <FormControl {...commonProps}>
          <InputLabel>{field.label}</InputLabel>
          <Select value={value || ""} label={field.label} onChange={(e) => onChange(e.target.value)}>
            {field.options?.map((option) => (
              <MenuItem key={option.value} value={option.value}>
                {option.label}
              </MenuItem>
            ))}
          </Select>
          {error && <FormHelperText>{helperText}</FormHelperText>}
        </FormControl>
      )
      break
    case "radio":
      fieldComponent = (
        <FormControl component="fieldset" {...commonProps}>
          <InputLabel shrink>{field.label}</InputLabel>
          <RadioGroup value={value || ""} onChange={(e) => onChange(e.target.value)}>
            {field.options?.map((option) => (
              <FormControlLabel
                key={option.value}
                value={option.value}
                control={<Radio />}
                label={option.label}
                disabled={disabled}
              />
            ))}
          </RadioGroup>
          {error && <FormHelperText>{helperText}</FormHelperText>}
        </FormControl>
      )
      break
    case "checkbox":
      fieldComponent = (
        <FormControl component="fieldset" {...commonProps}>
          <InputLabel shrink>{field.label}</InputLabel>
          <FormGroup>
            {field.options?.map((option) => (
              <FormControlLabel
                key={option.value}
                control={
                  <Checkbox
                    checked={Array.isArray(value) ? value.includes(option.value) : false}
                    onChange={(e) => {
                      const newValues = Array.isArray(value) ? [...value] : []
                      if (e.target.checked) {
                        newValues.push(option.value)
                      } else {
                        const index = newValues.indexOf(option.value)
                        if (index > -1) {
                          newValues.splice(index, 1)
                        }
                      }
                      onChange(newValues)
                    }}
                    disabled={disabled}
                  />
                }
                label={option.label}
              />
            ))}
          </FormGroup>
          {error && <FormHelperText>{helperText}</FormHelperText>}
        </FormControl>
      )
      break
    default:
      fieldComponent = null
  }

  return <Box sx={{ mb: 2 }}>{fieldComponent}</Box> // Wrap in Box for consistent margin
}
