"use client"
import type { FormField, ValidationRule } from "@/lib/formSchema"
import { Box, Typography, FormControlLabel, Checkbox, TextField, FormGroup } from "@mui/material"

interface ValidationRulesEditorProps {
  field: FormField
  validations: ValidationRule[]
  onUpdate: (validations: ValidationRule[]) => void
}

export default function ValidationRulesEditor({ field, validations, onUpdate }: ValidationRulesEditorProps) {
  const getValidationRule = (type: ValidationRule["type"]): ValidationRule | undefined => {
    return validations.find((v) => v.type === type)
  }

  const toggleValidation = (type: ValidationRule["type"], defaultMessage: string) => {
    const existingRule = getValidationRule(type)
    if (existingRule) {
      onUpdate(validations.filter((v) => v.type !== type))
    } else {
      onUpdate([...validations, { type, message: defaultMessage }])
    }
  }

  const updateValidationValue = (type: ValidationRule["type"], value: string | number) => {
    onUpdate(validations.map((v) => (v.type === type ? { ...v, value: value } : v)))
  }

  const updateValidationMessage = (type: ValidationRule["type"], message: string) => {
    onUpdate(validations.map((v) => (v.type === type ? { ...v, message: message } : v)))
  }

  const isChecked = (type: ValidationRule["type"]) => !!getValidationRule(type)

  return (
    <Box sx={{ mt: 2, border: "1px dashed #ccc", p: 2, borderRadius: 1 }}>
      <Typography variant="subtitle1" gutterBottom>
        Validation Rules
      </Typography>

      <FormGroup>
        <FormControlLabel
          control={
            <Checkbox
              checked={isChecked("notEmpty")}
              onChange={() => toggleValidation("notEmpty", `${field.label} cannot be empty.`)}
            />
          }
          label="Not Empty"
        />
        {isChecked("notEmpty") && (
          <TextField
            label="Error Message"
            value={getValidationRule("notEmpty")?.message || ""}
            onChange={(e) => updateValidationMessage("notEmpty", e.target.value)}
            size="small"
            fullWidth
            sx={{ ml: 4, mb: 1 }}
          />
        )}

        {(field.type === "text" || field.type === "textarea") && (
          <>
            <FormControlLabel
              control={
                <Checkbox
                  checked={isChecked("minLength")}
                  onChange={() => toggleValidation("minLength", `${field.label} must be at least X characters.`)}
                />
              }
              label="Minimum Length"
            />
            {isChecked("minLength") && (
              <Box sx={{ ml: 4, mb: 1, display: "flex", gap: 1, alignItems: "center" }}>
                <TextField
                  label="Min Length"
                  type="number"
                  value={(getValidationRule("minLength")?.value as number) || ""}
                  onChange={(e) => updateValidationValue("minLength", Number.parseInt(e.target.value) || 0)}
                  size="small"
                  sx={{ width: 120 }}
                />
                <TextField
                  label="Error Message"
                  value={getValidationRule("minLength")?.message || ""}
                  onChange={(e) => updateValidationMessage("minLength", e.target.value)}
                  size="small"
                  fullWidth
                />
              </Box>
            )}

            <FormControlLabel
              control={
                <Checkbox
                  checked={isChecked("maxLength")}
                  onChange={() => toggleValidation("maxLength", `${field.label} cannot exceed X characters.`)}
                />
              }
              label="Maximum Length"
            />
            {isChecked("maxLength") && (
              <Box sx={{ ml: 4, mb: 1, display: "flex", gap: 1, alignItems: "center" }}>
                <TextField
                  label="Max Length"
                  type="number"
                  value={(getValidationRule("maxLength")?.value as number) || ""}
                  onChange={(e) => updateValidationValue("maxLength", Number.parseInt(e.target.value) || 0)}
                  size="small"
                  sx={{ width: 120 }}
                />
                <TextField
                  label="Error Message"
                  value={getValidationRule("maxLength")?.message || ""}
                  onChange={(e) => updateValidationMessage("maxLength", e.target.value)}
                  size="small"
                  fullWidth
                />
              </Box>
            )}
          </>
        )}

        {field.type === "text" && (
          <>
            <FormControlLabel
              control={
                <Checkbox
                  checked={isChecked("email")}
                  onChange={() => toggleValidation("email", "Please enter a valid email address.")}
                />
              }
              label="Email Format"
            />
            {isChecked("email") && (
              <TextField
                label="Error Message"
                value={getValidationRule("email")?.message || ""}
                onChange={(e) => updateValidationMessage("email", e.target.value)}
                size="small"
                fullWidth
                sx={{ ml: 4, mb: 1 }}
              />
            )}

            <FormControlLabel
              control={
                <Checkbox
                  checked={isChecked("url")}
                  onChange={() => toggleValidation("url", "Please enter a valid URL.")}
                />
              }
              label="URL Format"
            />
            {isChecked("url") && (
              <TextField
                label="Error Message"
                value={getValidationRule("url")?.message || ""}
                onChange={(e) => updateValidationMessage("url", e.target.value)}
                size="small"
                fullWidth
                sx={{ ml: 4, mb: 1 }}
              />
            )}

            <FormControlLabel
              control={
                <Checkbox
                  checked={isChecked("password")}
                  onChange={() =>
                    toggleValidation("password", "Password must be at least 8 characters and contain a number.")
                  }
                />
              }
              label="Custom Password Rule"
            />
            {isChecked("password") && (
              <Box sx={{ ml: 4, mb: 1, display: "flex", gap: 1, alignItems: "center" }}>
                <TextField
                  label="Password Rule (Regex)"
                  value={(getValidationRule("password")?.value as string) || ""}
                  onChange={(e) => updateValidationValue("password", e.target.value)}
                  size="small"
                  fullWidth
                  placeholder="e.g., (?=.*[0-9])(?=.{8,})"
                />
                <TextField
                  label="Error Message"
                  value={getValidationRule("password")?.message || ""}
                  onChange={(e) => updateValidationMessage("password", e.target.value)}
                  size="small"
                  fullWidth
                />
              </Box>
            )}

            <FormControlLabel
              control={
                <Checkbox
                  checked={isChecked("regex")}
                  onChange={() => toggleValidation("regex", "Input does not match the required pattern.")}
                />
              }
              label="Custom Regex"
            />
            {isChecked("regex") && (
              <Box sx={{ ml: 4, mb: 1, display: "flex", gap: 1, alignItems: "center" }}>
                <TextField
                  label="Regex Pattern"
                  value={(getValidationRule("regex")?.value as string) || ""}
                  onChange={(e) => updateValidationValue("regex", e.target.value)}
                  size="small"
                  fullWidth
                  placeholder="e.g., ^[A-Za-z]+$"
                />
                <TextField
                  label="Error Message"
                  value={getValidationRule("regex")?.message || ""}
                  onChange={(e) => updateValidationMessage("regex", e.target.value)}
                  size="small"
                  fullWidth
                />
              </Box>
            )}
          </>
        )}

        {field.type === "number" && (
          <>
            <FormControlLabel
              control={
                <Checkbox
                  checked={isChecked("minNumber")}
                  onChange={() => toggleValidation("minNumber", `${field.label} must be at least X.`)}
                />
              }
              label="Minimum Number Value"
            />
            {isChecked("minNumber") && (
              <Box sx={{ ml: 4, mb: 1, display: "flex", gap: 1, alignItems: "center" }}>
                <TextField
                  label="Min Value"
                  type="number"
                  value={(getValidationRule("minNumber")?.value as number) || ""}
                  onChange={(e) => updateValidationValue("minNumber", Number.parseFloat(e.target.value) || 0)}
                  size="small"
                  sx={{ width: 120 }}
                />
                <TextField
                  label="Error Message"
                  value={getValidationRule("minNumber")?.message || ""}
                  onChange={(e) => updateValidationMessage("minNumber", e.target.value)}
                  size="small"
                  fullWidth
                />
              </Box>
            )}

            <FormControlLabel
              control={
                <Checkbox
                  checked={isChecked("maxNumber")}
                  onChange={() => toggleValidation("maxNumber", `${field.label} cannot exceed X.`)}
                />
              }
              label="Maximum Number Value"
            />
            {isChecked("maxNumber") && (
              <Box sx={{ ml: 4, mb: 1, display: "flex", gap: 1, alignItems: "center" }}>
                <TextField
                  label="Max Value"
                  type="number"
                  value={(getValidationRule("maxNumber")?.value as number) || ""}
                  onChange={(e) => updateValidationValue("maxNumber", Number.parseFloat(e.target.value) || 0)}
                  size="small"
                  sx={{ width: 120 }}
                />
                <TextField
                  label="Error Message"
                  value={getValidationRule("maxNumber")?.message || ""}
                  onChange={(e) => updateValidationMessage("maxNumber", e.target.value)}
                  size="small"
                  fullWidth
                />
              </Box>
            )}
          </>
        )}
      </FormGroup>
    </Box>
  )
}
