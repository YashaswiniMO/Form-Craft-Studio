"use client"
import type { FormField } from "@/lib/formSchema"
import { Button, Box } from "@mui/material"

interface FieldTypeSelectorProps {
  onSelectType: (type: FormField["type"]) => void
}

export default function FieldTypeSelector({ onSelectType }: FieldTypeSelectorProps) {
  const fieldTypes: FormField["type"][] = ["text", "number", "textarea", "select", "radio", "checkbox", "date"]

  return (
    <Box sx={{ display: "flex", flexWrap: "wrap", gap: 1, mb: 2 }}>
      {fieldTypes.map((type) => (
        <Button key={type} variant="outlined" onClick={() => onSelectType(type)} size="small">
          {type.charAt(0).toUpperCase() + type.slice(1)}
        </Button>
      ))}
    </Box>
  )
}
