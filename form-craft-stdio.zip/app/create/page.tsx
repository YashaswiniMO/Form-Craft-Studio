"use client"

import type React from "react"

import { useState, useRef } from "react" // Import useRef
import { useSelector, useDispatch } from "react-redux"
import type { RootState } from "@/redux/store"
import {
  addField,
  updateField,
  removeField,
  reorderField,
  setSelectedField,
  updateFormName,
  resetForm,
  loadFormSchema, // Import loadFormSchema
} from "@/redux/slices/formBuilderSlice"
import { saveForm } from "@/redux/slices/formsSlice"
import type { FormField, FormSchema } from "@/lib/formSchema" // Import FormSchema
import { v4 as uuidv4 } from "uuid"
import {
  Box,
  Button,
  TextField,
  Typography,
  Paper,
  List,
  ListItemText,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Snackbar,
  Alert,
  Grid,
  ListItemButton,
} from "@mui/material"
import AddIcon from "@mui/icons-material/Add"
import DeleteIcon from "@mui/icons-material/Delete"
import ArrowUpwardIcon from "@mui/icons-material/ArrowUpward"
import ArrowDownwardIcon from "@mui/icons-material/ArrowDownward"
import ArrowBackIcon from "@mui/icons-material/ArrowBack"
import UploadFileIcon from "@mui/icons-material/UploadFile" // Import UploadFileIcon
import DownloadIcon from "@mui/icons-material/Download" // Import DownloadIcon
import FieldConfigurator from "@/components/FieldConfigurator"
import FieldTypeSelector from "@/components/FieldTypeSelector"
import Link from "next/link"

export default function CreateFormPage() {
  const dispatch = useDispatch()
  const { currentForm, selectedFieldId } = useSelector((state: RootState) => state.formBuilder)
  const [newFormName, setNewFormName] = useState(currentForm.name)
  const [saveDialogOpen, setSaveDialogOpen] = useState(false)
  const [snackbarOpen, setSnackbarOpen] = useState(false)
  const [snackbarMessage, setSnackbarMessage] = useState("")
  const [snackbarSeverity, setSnackbarSeverity] = useState<"success" | "error">("success")

  const fileInputRef = useRef<HTMLInputElement>(null) // Ref for file input

  const handleAddField = (type: FormField["type"]) => {
    const newField: FormField = {
      id: uuidv4(),
      label: `New ${type} Field`,
      type: type,
      required: false,
      defaultValue: "",
      validations: [],
      isDerived: false,
    }
    if (type === "select" || type === "radio" || type === "checkbox") {
      newField.options = [{ label: "Option 1", value: "option1" }]
    }
    dispatch(addField(newField))
    dispatch(setSelectedField(newField.id))
  }

  const handleRemoveField = (id: string) => {
    dispatch(removeField(id))
    if (selectedFieldId === id) {
      dispatch(setSelectedField(null))
    }
  }

  const handleReorderField = (id: string, direction: "up" | "down") => {
    dispatch(reorderField({ id, direction }))
  }

  const handleSaveForm = () => {
    if (!newFormName.trim()) {
      setSnackbarMessage("Form name cannot be empty.")
      setSnackbarSeverity("error")
      setSnackbarOpen(true)
      return
    }
    if (currentForm.fields.length === 0) {
      setSnackbarMessage("Form must have at least one field to save.")
      setSnackbarSeverity("error")
      setSnackbarOpen(true)
      return
    }
    dispatch(saveForm({ ...currentForm, name: newFormName, createdAt: new Date().toISOString() }))
    dispatch(resetForm())
    setNewFormName("")
    setSaveDialogOpen(false)
    setSnackbarMessage("Form saved successfully!")
    setSnackbarSeverity("success")
    setSnackbarOpen(true)
  }

  const handleExportForm = () => {
    const formJson = JSON.stringify(currentForm, null, 2)
    const blob = new Blob([formJson], { type: "application/json" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `${currentForm.name.replace(/\s/g, "-").toLowerCase()}-schema.json`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
    setSnackbarMessage("Form schema exported successfully!")
    setSnackbarSeverity("success")
    setSnackbarOpen(true)
  }

  const handleImportForm = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (e) => {
        try {
          const importedSchema: FormSchema = JSON.parse(e.target?.result as string)
          // Basic validation for imported schema structure
          if (importedSchema.id && importedSchema.name && Array.isArray(importedSchema.fields)) {
            dispatch(loadFormSchema(importedSchema))
            setNewFormName(importedSchema.name)
            setSnackbarMessage(`Form "${importedSchema.name}" imported successfully!`)
            setSnackbarSeverity("success")
          } else {
            throw new Error("Invalid form schema structure.")
          }
        } catch (error: any) {
          setSnackbarMessage(`Failed to import form: ${error.message || "Invalid JSON file."}`)
          setSnackbarSeverity("error")
        } finally {
          setSnackbarOpen(true)
          // Clear the file input value to allow re-importing the same file
          if (fileInputRef.current) {
            fileInputRef.current.value = ""
          }
        }
      }
      reader.readAsText(file)
    }
  }

  const selectedField = currentForm.fields.find((field) => field.id === selectedFieldId)

  return (
    <Box sx={{ p: 3 }}>
      <Button variant="outlined" startIcon={<ArrowBackIcon />} component={Link} href="/" sx={{ mb: 3 }}>
        Back to Home
      </Button>
      <Typography variant="h4" gutterBottom sx={{ fontWeight: 600, color: "#3f51b5" }}>
        Form Builder
      </Typography>
      <Grid container spacing={3}>
        {/* Left Column: Form Fields and Add Field */}
        <Grid item xs={12} md={6} lg={5}>
          <Paper elevation={3} sx={{ p: 3, height: "100%" }}>
            <Typography variant="h6" gutterBottom sx={{ fontWeight: 500, color: "#424242" }}>
              Form Details
            </Typography>
            <TextField
              label="Form Name"
              value={newFormName}
              onChange={(e) => {
                setNewFormName(e.target.value)
                dispatch(updateFormName(e.target.value))
              }}
              fullWidth
              margin="normal"
              sx={{ mb: 3 }}
            />

            <Box sx={{ display: "flex", gap: 1, mb: 3 }}>
              <Button
                variant="outlined"
                startIcon={<DownloadIcon />}
                onClick={handleExportForm}
                disabled={currentForm.fields.length === 0}
              >
                Export Form
              </Button>
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleImportForm}
                style={{ display: "none" }}
                accept=".json"
              />
              <Button variant="outlined" startIcon={<UploadFileIcon />} onClick={() => fileInputRef.current?.click()}>
                Import Form
              </Button>
            </Box>

            <Typography variant="h6" gutterBottom sx={{ fontWeight: 500, color: "#424242" }}>
              Add New Field
            </Typography>
            <FieldTypeSelector onSelectType={handleAddField} />

            <Typography variant="h6" gutterBottom sx={{ mt: 4, fontWeight: 500, color: "#424242" }}>
              Form Fields
            </Typography>
            {currentForm.fields.length === 0 ? (
              <Typography
                variant="body2"
                color="textSecondary"
                sx={{ p: 2, border: "1px dashed #ccc", borderRadius: 1 }}
              >
                No fields added yet. Add a field to get started.
              </Typography>
            ) : (
              <List component={Paper} sx={{ maxHeight: 400, overflow: "auto", border: "1px solid #eee" }}>
                {currentForm.fields.map((field, index) => (
                  <ListItemButton
                    key={field.id}
                    onClick={() => dispatch(setSelectedField(field.id))}
                    sx={{
                      borderBottom: "1px solid #eee",
                      backgroundColor: selectedFieldId === field.id ? "#e0f7fa" : "inherit",
                      "&:hover": {
                        backgroundColor: selectedFieldId === field.id ? "#e0f7fa" : "#f5f5f5",
                      },
                    }}
                  >
                    <ListItemText primary={`${field.label} (${field.type})`} />
                    <Box>
                      <IconButton
                        edge="end"
                        aria-label="move up"
                        onClick={(e) => {
                          e.stopPropagation()
                          handleReorderField(field.id, "up")
                        }}
                        disabled={index === 0}
                        size="small"
                      >
                        <ArrowUpwardIcon fontSize="small" />
                      </IconButton>
                      <IconButton
                        edge="end"
                        aria-label="move down"
                        onClick={(e) => {
                          e.stopPropagation()
                          handleReorderField(field.id, "down")
                        }}
                        disabled={index === currentForm.fields.length - 1}
                        size="small"
                      >
                        <ArrowDownwardIcon fontSize="small" />
                      </IconButton>
                      <IconButton
                        edge="end"
                        aria-label="delete"
                        onClick={(e) => {
                          e.stopPropagation()
                          handleRemoveField(field.id)
                        }}
                        size="small"
                        color="error"
                      >
                        <DeleteIcon fontSize="small" />
                      </IconButton>
                    </Box>
                  </ListItemButton>
                ))}
              </List>
            )}

            <Button
              variant="contained"
              color="primary"
              startIcon={<AddIcon />}
              onClick={() => setSaveDialogOpen(true)}
              sx={{ mt: 3 }}
            >
              Save Form
            </Button>
          </Paper>
        </Grid>

        {/* Right Column: Field Configuration */}
        <Grid item xs={12} md={6} lg={7}>
          <Paper elevation={3} sx={{ p: 3, height: "100%" }}>
            <Typography variant="h5" gutterBottom sx={{ fontWeight: 600, color: "#3f51b5" }}>
              Field Configuration
            </Typography>
            {selectedField ? (
              <FieldConfigurator
                field={selectedField}
                allFields={currentForm.fields}
                onUpdate={(updatedField) => dispatch(updateField(updatedField))}
              />
            ) : (
              <Typography
                variant="body1"
                color="textSecondary"
                sx={{ p: 2, border: "1px dashed #ccc", borderRadius: 1 }}
              >
                Select a field from the list to configure its properties.
              </Typography>
            )}
          </Paper>
        </Grid>
      </Grid>

      <Dialog open={saveDialogOpen} onClose={() => setSaveDialogOpen(false)}>
        <DialogTitle>Save Form</DialogTitle>
        <DialogContent>
          <TextField
            autoFocus
            margin="dense"
            label="Form Name"
            type="text"
            fullWidth
            variant="standard"
            value={newFormName}
            onChange={(e) => setNewFormName(e.target.value)}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setSaveDialogOpen(false)}>Cancel</Button>
          <Button onClick={handleSaveForm} variant="contained">
            Save
          </Button>
        </DialogActions>
      </Dialog>

      <Snackbar open={snackbarOpen} autoHideDuration={6000} onClose={() => setSnackbarOpen(false)}>
        <Alert onClose={() => setSnackbarOpen(false)} severity={snackbarSeverity} sx={{ width: "100%" }}>
          {snackbarMessage}
        </Alert>
      </Snackbar>
    </Box>
  )
}
