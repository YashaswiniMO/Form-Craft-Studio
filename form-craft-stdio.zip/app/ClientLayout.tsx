"use client"

import type React from "react"
import { Poppins } from "next/font/google"
import "./globals.css"
import { MuiThemeProvider, useColorMode } from "@/components/MuiThemeProvider"
import { ReduxProvider } from "@/components/ReduxProvider"
import { AppBar, Toolbar, Typography, Button, Box, IconButton, useTheme } from "@mui/material" // Import useTheme
import Link from "next/link"
import Brightness4Icon from "@mui/icons-material/Brightness4"
import Brightness7Icon from "@mui/icons-material/Brightness7"

const poppins = Poppins({
  subsets: ["latin"],
  weight: ["300", "400", "500", "600", "700"],
})

// Component to render AppBar with theme toggle
function AppHeader() {
  const { mode, toggleColorMode } = useColorMode()
  const theme = useTheme() // Use theme to get palette colors

  return (
    <AppBar position="static" sx={{ backgroundColor: theme.palette.primary.main }}>
      <Toolbar>
        <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
          <Link href="/" style={{ textDecoration: "none", color: "inherit" }}>
            Form Craft Studio
          </Link>
        </Typography>
        <Box sx={{ display: { xs: "none", md: "flex" }, alignItems: "center" }}>
          <Button color="inherit" component={Link} href="/create">
            Create Form
          </Button>
          <Button color="inherit" component={Link} href="/preview">
            Preview
          </Button>
          <Button color="inherit" component={Link} href="/myforms">
            My Forms
          </Button>
          <IconButton sx={{ ml: 1 }} onClick={toggleColorMode} color="inherit">
            {mode === "dark" ? <Brightness7Icon /> : <Brightness4Icon />}
          </IconButton>
        </Box>
      </Toolbar>
    </AppBar>
  )
}

export default function ClientLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <body className={poppins.className}>
        <ReduxProvider>
          <MuiThemeProvider>
            <AppHeader />
            <Box component="main" sx={{ p: 3 }}>
              {children}
            </Box>
          </MuiThemeProvider>
        </ReduxProvider>
      </body>
    </html>
  )
}
