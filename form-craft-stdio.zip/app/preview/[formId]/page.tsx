"use client"

import { useEffect, useState } from "react"
import { useSelector } from "react-redux"
import type { RootState } from "@/redux/store"
import FormPreview from "@/components/FormPreview"
import { Box, Typography, CircularProgress, Paper, Button } from "@mui/material"
import type { FormSchema } from "@/lib/formSchema"
import Link from "next/link"
import ArrowBackIcon from "@mui/icons-material/ArrowBack"

interface PreviewSavedFormPageProps {
  params: {
    formId: string
  }
}

export default function PreviewSavedFormPage({ params }: PreviewSavedFormPageProps) {
  const { formId } = params
  const savedForms = useSelector((state: RootState) => state.forms.savedForms)
  const [formSchema, setFormSchema] = useState<FormSchema | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (savedForms.length > 0) {
      const foundForm = savedForms.find((form) => form.id === formId)
      setFormSchema(foundForm || null)
      setLoading(false)
    } else {
      setLoading(false)
    }
  }, [formId, savedForms])

  if (loading) {
    return (
      <Box sx={{ display: "flex", justifyContent: "center", alignItems: "center", height: "80vh" }}>
        <CircularProgress />
      </Box>
    )
  }

  if (!formSchema) {
    return (
      <Paper elevation={3} sx={{ p: 3, mt: 3 }}>
        <Button variant="outlined" startIcon={<ArrowBackIcon />} component={Link} href="/" sx={{ mb: 3 }}>
          Back to Home
        </Button>
        <Typography variant="h5" color="error">
          Form not found.
        </Typography>
        <Typography variant="body1" color="textSecondary">
          The form with ID "{formId}" could not be loaded. It might have been deleted or the link is incorrect.
        </Typography>
      </Paper>
    )
  }

  return (
    <Box sx={{ p: 3 }}>
      <Button variant="outlined" startIcon={<ArrowBackIcon />} component={Link} href="/" sx={{ mb: 3 }}>
        Back to Home
      </Button>
      <Typography variant="h4" gutterBottom sx={{ fontWeight: 600, color: "#3f51b5" }}>
        Preview: {formSchema.name}
      </Typography>
      <FormPreview formSchema={formSchema} />
    </Box>
  )
}
