"use client"
import { useSelector } from "react-redux"
import type { RootState } from "@/redux/store"
import FormPreview from "@/components/FormPreview"
import { Box, Typography, Paper, Button } from "@mui/material"
import Link from "next/link"
import ArrowBackIcon from "@mui/icons-material/ArrowBack"

export default function PreviewCurrentFormPage() {
  const currentForm = useSelector((state: RootState) => state.formBuilder.currentForm)

  return (
    <Box sx={{ p: 3 }}>
      <Button variant="outlined" startIcon={<ArrowBackIcon />} component={Link} href="/" sx={{ mb: 3 }}>
        Back to Home
      </Button>
      <Typography variant="h4" gutterBottom sx={{ fontWeight: 600, color: "#3f51b5" }}>
        Preview Current Form
      </Typography>
      {currentForm.fields.length === 0 ? (
        <Paper elevation={3} sx={{ p: 3, mt: 3 }}>
          <Typography variant="body1" color="textSecondary">
            No form fields to preview. Please go to the "Create Form" page to build a form.
          </Typography>
        </Paper>
      ) : (
        <FormPreview formSchema={currentForm} />
      )}
    </Box>
  )
}
