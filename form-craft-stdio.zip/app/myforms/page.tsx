"use client"

import { useEffect } from "react"
import { useSelector, useDispatch } from "react-redux"
import type { RootState } from "@/redux/store"
import { loadForms, deleteForm } from "@/redux/slices/formsSlice" // Import deleteForm
import { Box, Typography, List, ListItem, ListItemText, Paper, Button, IconButton, Alert } from "@mui/material" // Import IconButton, Alert
import Link from "next/link"
import ArrowBackIcon from "@mui/icons-material/ArrowBack"
import DeleteIcon from "@mui/icons-material/Delete" // Import DeleteIcon

export default function MyFormsPage() {
  const dispatch = useDispatch()
  const savedForms = useSelector((state: RootState) => state.forms.savedForms)

  useEffect(() => {
    dispatch(loadForms())
  }, [dispatch])

  const handleDeleteForm = (formId: string, formName: string) => {
    if (window.confirm(`Are you sure you want to delete the form "${formName}"?`)) {
      dispatch(deleteForm(formId))
    }
  }

  return (
    <Box sx={{ p: 3 }}>
      <Button variant="outlined" startIcon={<ArrowBackIcon />} component={Link} href="/" sx={{ mb: 3 }}>
        Back to Home
      </Button>
      <Typography variant="h4" gutterBottom sx={{ fontWeight: 600, color: "#3f51b5" }}>
        My Saved Forms (Templates)
      </Typography>
      <Alert severity="info" sx={{ mb: 3 }}>
        This page lists your saved form *templates* (schemas). User input from previews is not stored.
      </Alert>
      {savedForms.length === 0 ? (
        <Paper elevation={3} sx={{ p: 3, mt: 3 }}>
          <Typography variant="body1" color="textSecondary">
            No forms saved yet. Go to the "Create Form" page to build and save your first form!
          </Typography>
        </Paper>
      ) : (
        <List component={Paper} elevation={3} sx={{ maxHeight: 600, overflow: "auto" }}>
          {savedForms.map((form) => (
            <ListItem
              key={form.id}
              secondaryAction={
                <IconButton
                  edge="end"
                  aria-label="delete"
                  onClick={() => handleDeleteForm(form.id, form.name)}
                  color="error"
                >
                  <DeleteIcon />
                </IconButton>
              }
              sx={{
                borderBottom: "1px solid #eee",
                "&:last-child": { borderBottom: "none" },
                "&:hover": { backgroundColor: "#f5f5f5" },
                py: 1.5,
              }}
            >
              <ListItemText
                primary={
                  <Link href={`/preview/${form.id}`} style={{ textDecoration: "none", color: "inherit" }}>
                    <Typography variant="h6" sx={{ fontWeight: 500 }}>
                      {form.name}
                    </Typography>
                  </Link>
                }
                secondary={`Created: ${new Date(form.createdAt).toLocaleDateString()} at ${new Date(
                  form.createdAt,
                ).toLocaleTimeString()}`}
                sx={{ mr: 2 }}
              />
            </ListItem>
          ))}
        </List>
      )}
    </Box>
  )
}
