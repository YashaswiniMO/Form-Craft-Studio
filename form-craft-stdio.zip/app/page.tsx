import { Box, Typography, Button, Container, Grid } from "@mui/material"
import Link from "next/link"
import CreateIcon from "@mui/icons-material/Create"
import VisibilityIcon from "@mui/icons-material/Visibility"
import ListAltIcon from "@mui/icons-material/ListAlt"

export default function HomePage() {
  return (
    <Box
      sx={{
        minHeight: "calc(100vh - 64px)", // Adjust for AppBar height
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        textAlign: "center",
        background: "radial-gradient(circle at top left, #e0f7fa, #bbdefb, #90caf9)", // More interesting radial gradient
        py: 8,
        px: 2,
      }}
    >
      <Container maxWidth="md">
        <Typography
          variant="h2"
          component="h1"
          gutterBottom
          sx={{
            fontWeight: 700,
            color: "#1a237e", // Dark blue
            mb: 3,
            textShadow: "2px 2px 4px rgba(0,0,0,0.1)",
          }}
        >
          Form Craft Studio
        </Typography>
        <Typography
          variant="h5"
          component="p"
          sx={{
            color: "#3f51b5", // Medium blue
            mb: 5,
            maxWidth: 600,
            mx: "auto",
          }}
        >
          Unleash your creativity and build dynamic, customizable forms with ease. Design, preview, and manage all your
          forms in one intuitive studio. 🚀
        </Typography>

        <Grid container spacing={3} justifyContent="center">
          <Grid item xs={12} sm={6} md={4}>
            <Button
              variant="contained"
              color="primary"
              size="large"
              startIcon={<CreateIcon />}
              component={Link}
              href="/create"
              sx={{
                width: "100%",
                py: 2,
                borderRadius: 2,
                boxShadow: "0 4px 10px rgba(0,0,0,0.1)",
                "&:hover": {
                  transform: "translateY(-2px)",
                  boxShadow: "0 6px 15px rgba(0,0,0,0.2)",
                },
              }}
            >
              Create New Form 📝
            </Button>
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <Button
              variant="contained"
              color="secondary"
              size="large"
              startIcon={<VisibilityIcon />}
              component={Link}
              href="/preview"
              sx={{
                width: "100%",
                py: 2,
                borderRadius: 2,
                boxShadow: "0 4px 10px rgba(0,0,0,0.1)",
                "&:hover": {
                  transform: "translateY(-2px)",
                  boxShadow: "0 6px 15px rgba(0,0,0,0.2)",
                },
              }}
            >
              Preview Form 👀
            </Button>
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <Button
              variant="contained"
              color="info"
              size="large"
              startIcon={<ListAltIcon />}
              component={Link}
              href="/myforms"
              sx={{
                width: "100%",
                py: 2,
                borderRadius: 2,
                boxShadow: "0 4px 10px rgba(0,0,0,0.1)",
                "&:hover": {
                  transform: "translateY(-2px)",
                  boxShadow: "0 6px 15px rgba(0,0,0,0.2)",
                },
              }}
            >
              My Saved Forms 🗂️
            </Button>
          </Grid>
        </Grid>
      </Container>
    </Box>
  )
}
