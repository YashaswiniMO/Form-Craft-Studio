import { createSlice, type PayloadAction } from "@reduxjs/toolkit"
import type { FormSchema } from "@/lib/formSchema"
import { loadFormsFromLocalStorage, saveFormsToLocalStorage } from "@/lib/localStorage"
import { v4 as uuidv4 } from "uuid"

interface FormsState {
  savedForms: FormSchema[]
}

const initialState: FormsState = {
  savedForms: loadFormsFromLocalStorage(),
}

const formsSlice = createSlice({
  name: "forms",
  initialState,
  reducers: {
    saveForm: (state, action: PayloadAction<Omit<FormSchema, "id" | "createdAt">>) => {
      const newForm: FormSchema = {
        ...action.payload,
        id: uuidv4(), // Ensure a new unique ID for saved forms
        createdAt: new Date().toISOString(),
      }
      state.savedForms.push(newForm)
      saveFormsToLocalStorage(state.savedForms)
    },
    loadForms: (state) => {
      state.savedForms = loadFormsFromLocalStorage()
    },
    deleteForm: (state, action: PayloadAction<string>) => {
      state.savedForms = state.savedForms.filter((form) => form.id !== action.payload)
      saveFormsToLocalStorage(state.savedForms)
    },
  },
})

export const { saveForm, loadForms, deleteForm } = formsSlice.actions

export default formsSlice.reducer
