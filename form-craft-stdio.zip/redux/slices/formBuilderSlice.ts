import { createSlice, type PayloadAction } from "@reduxjs/toolkit"
import type { FormField, FormSchema } from "@/lib/formSchema" // Import FormSchema
import { v4 as uuidv4 } from "uuid"

interface FormBuilderState {
  currentForm: {
    id: string
    name: string
    fields: FormField[]
  }
  selectedFieldId: string | null
}

const initialState: FormBuilderState = {
  currentForm: {
    id: uuidv4(),
    name: "New Form",
    fields: [],
  },
  selectedFieldId: null,
}

const formBuilderSlice = createSlice({
  name: "formBuilder",
  initialState,
  reducers: {
    addField: (state, action: PayloadAction<FormField>) => {
      state.currentForm.fields.push(action.payload)
    },
    updateField: (state, action: PayloadAction<FormField>) => {
      const index = state.currentForm.fields.findIndex((field) => field.id === action.payload.id)
      if (index !== -1) {
        state.currentForm.fields[index] = action.payload
      }
    },
    removeField: (state, action: PayloadAction<string>) => {
      const removedFieldId = action.payload
      state.currentForm.fields = state.currentForm.fields.filter((field) => field.id !== removedFieldId)

      // After removing a field, update any derived fields that used it as a parent
      state.currentForm.fields.forEach((field) => {
        if (field.isDerived && field.parentFieldIds) {
          field.parentFieldIds = field.parentFieldIds.filter((parentId) => parentId !== removedFieldId)
        }
        // Also update conditional fields that depended on the removed field
        if (field.isConditional && field.conditionFieldId === removedFieldId) {
          field.conditionFieldId = undefined
          field.conditionOperator = undefined
          field.conditionValue = undefined
          field.isConditional = false // Optionally reset conditional if its parent is gone
        }
      })
    },
    reorderField: (state, action: PayloadAction<{ id: string; direction: "up" | "down" }>) => {
      const { id, direction } = action.payload
      const index = state.currentForm.fields.findIndex((field) => field.id === id)
      if (index === -1) return

      if (direction === "up" && index > 0) {
        const [removed] = state.currentForm.fields.splice(index, 1)
        state.currentForm.fields.splice(index - 1, 0, removed)
      } else if (direction === "down" && index < state.currentForm.fields.length - 1) {
        const [removed] = state.currentForm.fields.splice(index, 1)
        state.currentForm.fields.splice(index + 1, 0, removed)
      }
    },
    setSelectedField: (state, action: PayloadAction<string | null>) => {
      state.selectedFieldId = action.payload
    },
    updateFormName: (state, action: PayloadAction<string>) => {
      state.currentForm.name = action.payload
    },
    resetForm: (state) => {
      state.currentForm = {
        id: uuidv4(),
        name: "New Form",
        fields: [],
      }
      state.selectedFieldId = null
    },
    loadFormSchema: (state, action: PayloadAction<FormSchema>) => {
      state.currentForm = {
        ...action.payload,
        id: uuidv4(), // Assign a new ID to the loaded form to treat it as a new session
        createdAt: new Date().toISOString(), // Update creation date
      }
      state.selectedFieldId = null
    },
  },
})

export const {
  addField,
  updateField,
  removeField,
  reorderField,
  setSelectedField,
  updateFormName,
  resetForm,
  loadFormSchema,
} = formBuilderSlice.actions

export default formBuilderSlice.reducer
